# PIN Settings

Original Settings jaisi list. Har row asli Android Settings page kholti hai, isliye wahan ke saare toggle asli kaam karte hain.
App kholne par 4 digit ka PIN maangti hai (number pad, 4 dots, 4th digit par apne aap check).

## Rows
- Wi-Fi, Bluetooth, Mobile networks, Portable hotspot
- Fingerprints / face data / screen lock, Privacy protection, Apps

## APK banana
**GitHub se (PC ke bina)**
1. Is folder ki saari files ek naye GitHub repo me upload karo.
2. `.github/workflows/build.yml` honi chahiye. Na ho to `BUILD_WORKFLOW.yml` ka content us path par paste karo.
3. Actions tab me "Build APK" chalao (Run workflow).
4. Khatam hone par Artifacts me `PinSettings-apk` download karo. Zip kholkar `app-debug.apk` install karo.

**Android Studio se:** project kholo, Build, Build APK(s).

## Dhyan rakho
- PIN exactly 4 digit ka hai. Pehli baar do baar dalna padta hai. 5 galat try ke baad kuch der wait.
- PIN badalna ya bhool jao to: phone Settings, Apps, PIN Settings, Clear data (ya app uninstall karke dobara install). Phir app naya PIN maangegi.
- App sirf asli Settings pages kholti hai. Device owner, uninstall protection ya Settings lock isme nahi hai.
- Wi-Fi, Bluetooth, hotspot ke toggle Android third-party app ko khud karne nahi deta. Isliye app asli Settings page kholti hai.
- Agar koi row ka page seedha na khule to main Settings khulti hai.
