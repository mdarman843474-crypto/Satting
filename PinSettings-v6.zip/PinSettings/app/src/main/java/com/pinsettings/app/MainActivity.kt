package com.pinsettings.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private var unlocked = false
        private var leftAt = 0L
    }

    private val bg = Color.BLACK
    private val cardColor = Color.parseColor("#242424")
    private val white = Color.WHITE
    private val gray = Color.parseColor("#8E8E93")
    private val blue = Color.parseColor("#2F80ED")
    private val green = Color.parseColor("#1FBF5B")
    private val purple = Color.parseColor("#8B7CF6")

    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private var scroll: ScrollView? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        route()
    }

    override fun onStart() {
        super.onStart()
        if (!unlocked) return
        if (leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > 60_000L) {
            // 1 minute se zyada bahar rahe: dobara PIN
            unlocked = false
            route()
        } else if (scroll != null) {
            refresh()
        }
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
    }

    private fun route() {
        if (!PinStore.isSet(this)) {
            showPin(true)
        } else if (!unlocked) {
            showPin(false)
        } else {
            showHome()
        }
    }

    private fun refresh() {
        val y = scroll?.scrollY ?: 0
        showHome()
        scroll?.post { scroll?.scrollTo(0, y) }
    }

    // ---------------------------------------------------------------- PIN lock (4 digit)

    private var firstPin: String? = null

    private fun showPin(setup: Boolean) {
        firstPin = null
        showPad(
            if (setup) "Naya PIN set karo" else "PIN dalo",
            if (setup) "4 digit ka PIN. Ye yaad rakhna." else "Settings kholne ke liye PIN dalo",
            setup,
            ""
        )
    }

    /** null = PIN sahi, warna dikhane wala error message. */
    private fun pinError(pin: String): String? {
        val wait = PinStore.waitMs(this)
        if (wait > 0L) return "Ruko, ${wait / 1000 + 1} second baad try karo"
        return if (PinStore.check(this, pin)) null else "Galat PIN"
    }

    private fun showPad(title: String, sub: String, setup: Boolean, note: String) {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        val entered = StringBuilder()
        val dotViews = ArrayList<TextView>()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(24), dp(48), dp(24), dp(24))

        val t = label(title, 28f, white, true)
        t.gravity = Gravity.CENTER
        box.addView(t, LinearLayout.LayoutParams(match, wrap))

        val s = label(sub, 14f, gray)
        s.gravity = Gravity.CENTER
        s.setPadding(0, dp(8), 0, dp(28))
        box.addView(s, LinearLayout.LayoutParams(match, wrap))

        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER
        for (k in 0 until 4) {
            val d = label("\u25CB", 30f, white)
            d.setPadding(dp(10), 0, dp(10), 0)
            dots.addView(d)
            dotViews.add(d)
        }
        box.addView(dots, LinearLayout.LayoutParams(match, wrap))

        val msg = label(note, 14f, Color.parseColor("#FF6B6B"))
        msg.gravity = Gravity.CENTER
        msg.setPadding(0, dp(14), 0, dp(14))
        box.addView(msg, LinearLayout.LayoutParams(match, wrap))

        fun refreshDots() {
            for (k in 0 until 4) {
                dotViews[k].text = if (k < entered.length) "\u25CF" else "\u25CB"
            }
        }

        fun complete(pin: String) {
            if (setup) {
                val first = firstPin
                if (first == null) {
                    firstPin = pin
                    showPad("PIN dobara dalo", "Wahi 4 digit phir se dalo", true, "")
                } else if (first == pin) {
                    PinStore.save(this, pin)
                    firstPin = null
                    unlocked = true
                    showHome()
                } else {
                    firstPin = null
                    showPad(
                        "Naya PIN set karo", "4 digit ka PIN. Ye yaad rakhna.", true,
                        "Dono PIN match nahi hue"
                    )
                }
            } else {
                val err = pinError(pin)
                if (err == null) {
                    unlocked = true
                    showHome()
                } else {
                    entered.setLength(0)
                    refreshDots()
                    msg.text = err
                }
            }
        }

        fun press(d: String) {
            if (entered.length >= 4) return
            entered.append(d)
            refreshDots()
            msg.text = ""
            if (entered.length == 4) complete(entered.toString())
        }

        fun erase() {
            if (entered.isNotEmpty()) {
                entered.setLength(entered.length - 1)
                refreshDots()
            }
        }

        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9")
        )
        for (r in rows) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER
            for (d in r) line.addView(padKey(d) { press(d) })
            box.addView(line, LinearLayout.LayoutParams(match, wrap))
        }
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        bottom.addView(padBlank())
        bottom.addView(padKey("0") { press("0") })
        bottom.addView(padKey("\u2190") { erase() })
        box.addView(bottom, LinearLayout.LayoutParams(match, wrap))

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        sv.isFillViewport = true
        sv.addView(box)
        setContentView(sv)
    }

    private fun padKey(txt: String, onClick: () -> Unit): View {
        val k = TextView(this)
        k.text = txt
        k.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        k.setTextColor(white)
        k.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(cardColor)
        k.background = g
        k.setOnClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onClick()
        }
        val lp = LinearLayout.LayoutParams(dp(76), dp(76))
        lp.setMargins(dp(12), dp(8), dp(12), dp(8))
        k.layoutParams = lp
        return k
    }

    private fun padBlank(): View {
        val v = View(this)
        val lp = LinearLayout.LayoutParams(dp(76), dp(76))
        lp.setMargins(dp(12), dp(8), dp(12), dp(8))
        v.layoutParams = lp
        return v
    }

    // ---------------------------------------------------------------- Home

    private fun showHome() {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(28), dp(16), dp(36))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(label("Settings", 34f, white, true), LinearLayout.LayoutParams(0, wrap, 1f))
        val lockBtn = label("Lock", 16f, Color.parseColor("#4C9AFF"))
        lockBtn.setPadding(dp(12), dp(8), dp(12), dp(8))
        lockBtn.setOnClickListener {
            unlocked = false
            route()
        }
        head.addView(lockBtn)
        col.addView(head)
        col.addView(space(18))

        col.addView(
            card(
                row(R.drawable.ic_wifi, blue, "Wi-Fi", wifiState()) { openPage(Links.wifi) },
                row(R.drawable.ic_bluetooth, blue, "Bluetooth", btState()) { openPage(Links.bluetooth) },
                row(R.drawable.ic_mobile, green, "Mobile networks", null) { openPage(Links.mobile) },
                row(R.drawable.ic_hotspot, blue, "Portable hotspot", null) { openPage(Links.hotspot) }
            )
        )
        col.addView(space(14))

        col.addView(
            card(
                row(R.drawable.ic_fingerprint, purple, "Fingerprints, face data, and screen lock", null) {
                    openPage(Links.lock)
                },
                row(R.drawable.ic_privacy, blue, "Privacy protection", null) { openPage(Links.privacy) },
                row(R.drawable.ic_apps, blue, "Apps", null) { openPage(Links.apps) }
            )
        )

        val s = ScrollView(this)
        s.setBackgroundColor(bg)
        s.addView(col)
        scroll = s
        setContentView(s)
    }

    // ---------------------------------------------------------------- actions

    private fun openPage(list: List<Intent>) {
        for (i in list) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // agla intent try karo
            }
        }
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (e: Exception) {
            toast("Ye screen khul nahi saki")
        }
    }

    private fun wifiState(): String {
        return try {
            val w = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (w.isWifiEnabled) "On" else "Off"
        } catch (e: Exception) {
            ""
        }
    }

    private fun btState(): String {
        return try {
            when (Settings.Global.getInt(contentResolver, "bluetooth_on", -1)) {
                1 -> "On"
                0 -> "Off"
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    // ---------------------------------------------------------------- view helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    private fun selectable(): Int {
        val v = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, v, true)
        return v.resourceId
    }

    private fun card(vararg rows: View): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.setColor(cardColor)
        g.cornerRadius = dp(22).toFloat()
        c.background = g
        c.outlineProvider = ViewOutlineProvider.BACKGROUND
        c.clipToOutline = true
        for (r in rows) c.addView(r)
        return c
    }

    private fun tile(icon: Int, color: Int): View {
        val f = FrameLayout(this)
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(11).toFloat()
        f.background = g
        val iv = ImageView(this)
        iv.setImageResource(icon)
        f.addView(iv, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        f.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        return f
    }

    private fun row(icon: Int, color: Int, title: String, value: String?, click: () -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(13), dp(14), dp(13))
        r.setBackgroundResource(selectable())
        r.setOnClickListener { click() }
        r.addView(tile(icon, color))

        val lp = LinearLayout.LayoutParams(0, wrap, 1f)
        lp.leftMargin = dp(16)
        r.addView(label(title, 17f, white), lp)

        if (!value.isNullOrEmpty()) {
            val v = label(value, 15f, gray)
            v.setPadding(0, 0, dp(6), 0)
            r.addView(v)
        }
        r.addView(label("\u203A", 26f, gray))
        return r
    }
}
